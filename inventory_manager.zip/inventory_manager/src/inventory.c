#include "inventory.h"

#include <stdio.h>
#include <string.h>

/* ------------------------------------------------------------------ helpers */

/* Open the inventory file. mode follows fopen conventions.
   Returns NULL on failure. */
static FILE *open_file(const char *mode)
{
    return fopen(INVENTORY_FILE, mode);
}

/* Return the byte offset of record index n (0-based). */
static long record_offset(long n)
{
    return n * (long)sizeof(Item);
}

/* Count total records (including deleted) in the file.
   Returns -1 on error. */
static long record_count(FILE *fp)
{
    if (fseek(fp, 0L, SEEK_END) != 0) return -1;
    long size = ftell(fp);
    if (size < 0) return -1;
    return size / (long)sizeof(Item);
}

/* ------------------------------------------------------------------ C API */

int add_item(const Item item)
{
    /* Validate basic constraints */
    if (item.id <= 0)              return 0;
    if (item.name[0] == '\0')      return 0;
    if (item.quantity < 0)         return 0;
    if (item.price < 0.0f)         return 0;

    /* Open for reading first to check for duplicate IDs */
    FILE *fp = open_file("rb+");
    if (fp == NULL) {
        /* File does not exist yet – create it */
        fp = open_file("wb");
        if (fp == NULL) return 0;
        if (fwrite(&item, sizeof(Item), 1, fp) != 1) { fclose(fp); return 0; }
        fclose(fp);
        return 1;
    }

    /* Scan existing records for duplicate id */
    long count = record_count(fp);
    if (count < 0) { fclose(fp); return 0; }

    for (long i = 0; i < count; i++) {
        Item tmp;
        if (fseek(fp, record_offset(i), SEEK_SET) != 0) { fclose(fp); return 0; }
        if (fread(&tmp, sizeof(Item), 1, fp) != 1)       { fclose(fp); return 0; }
        if (!tmp.is_deleted && tmp.id == item.id)        { fclose(fp); return 0; }
    }

    /* Append new record */
    if (fseek(fp, 0L, SEEK_END) != 0) { fclose(fp); return 0; }
    if (fwrite(&item, sizeof(Item), 1, fp) != 1) { fclose(fp); return 0; }
    fclose(fp);
    return 1;
}

int get_item(int id, Item *out)
{
    if (id <= 0 || out == NULL) return 0;

    FILE *fp = open_file("rb");
    if (fp == NULL) return 0;

    long count = record_count(fp);
    if (count < 0) { fclose(fp); return 0; }

    for (long i = 0; i < count; i++) {
        Item tmp;
        if (fseek(fp, record_offset(i), SEEK_SET) != 0) { fclose(fp); return 0; }
        if (fread(&tmp, sizeof(Item), 1, fp) != 1)       { fclose(fp); return 0; }
        if (!tmp.is_deleted && tmp.id == id) {
            *out = tmp;
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int update_item(int id, const Item updated)
{
    if (id <= 0) return 0;

    FILE *fp = open_file("rb+");
    if (fp == NULL) return 0;

    long count = record_count(fp);
    if (count < 0) { fclose(fp); return 0; }

    for (long i = 0; i < count; i++) {
        Item tmp;
        if (fseek(fp, record_offset(i), SEEK_SET) != 0) { fclose(fp); return 0; }
        if (fread(&tmp, sizeof(Item), 1, fp) != 1)       { fclose(fp); return 0; }
        if (!tmp.is_deleted && tmp.id == id) {
            /* Seek back to overwrite */
            if (fseek(fp, record_offset(i), SEEK_SET) != 0) { fclose(fp); return 0; }
            Item to_write = updated;
            to_write.id = id;          /* preserve original id */
            to_write.is_deleted = 0;   /* never accidentally delete via update */
            if (fwrite(&to_write, sizeof(Item), 1, fp) != 1) { fclose(fp); return 0; }
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int delete_item(int id)
{
    if (id <= 0) return 0;

    FILE *fp = open_file("rb+");
    if (fp == NULL) return 0;

    long count = record_count(fp);
    if (count < 0) { fclose(fp); return 0; }

    for (long i = 0; i < count; i++) {
        Item tmp;
        if (fseek(fp, record_offset(i), SEEK_SET) != 0) { fclose(fp); return 0; }
        if (fread(&tmp, sizeof(Item), 1, fp) != 1)       { fclose(fp); return 0; }
        if (!tmp.is_deleted && tmp.id == id) {
            tmp.is_deleted = 1;
            if (fseek(fp, record_offset(i), SEEK_SET) != 0) { fclose(fp); return 0; }
            if (fwrite(&tmp, sizeof(Item), 1, fp) != 1)      { fclose(fp); return 0; }
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int list_items(Item *buffer, int max_items)
{
    if (buffer == NULL || max_items <= 0) return 0;

    FILE *fp = open_file("rb");
    if (fp == NULL) return 0;

    long count = record_count(fp);
    if (count < 0) { fclose(fp); return 0; }

    int copied = 0;
    for (long i = 0; i < count && copied < max_items; i++) {
        Item tmp;
        if (fseek(fp, record_offset(i), SEEK_SET) != 0) { fclose(fp); return copied; }
        if (fread(&tmp, sizeof(Item), 1, fp) != 1)       { fclose(fp); return copied; }
        if (!tmp.is_deleted) {
            buffer[copied++] = tmp;
        }
    }

    fclose(fp);
    return copied;
}
