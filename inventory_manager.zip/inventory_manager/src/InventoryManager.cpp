#include "InventoryManager.h"
#include "inventory.h"

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <cstring>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

/* ============================================================ helpers (private) */

void InventoryManager::printHeader()
{
    std::cout << "\n"
              << std::left
              << std::setw(6)  << "ID"
              << std::setw(42) << "Name"
              << std::setw(10) << "Qty"
              << std::setw(12) << "Price ($)"
              << "\n"
              << std::string(70, '-')
              << "\n";
}

void InventoryManager::printItem(const Item &item)
{
    std::cout << std::left
              << std::setw(6)  << item.id
              << std::setw(42) << item.name
              << std::setw(10) << item.quantity
              << std::fixed << std::setprecision(2)
              << std::setw(12) << item.price
              << "\n";
}

int InventoryManager::readPositiveInt(const std::string &prompt)
{
    int value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value && value > 0) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  [!] Must be a positive integer. Try again.\n";
    }
}

int InventoryManager::readNonNegativeInt(const std::string &prompt)
{
    int value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value && value >= 0) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  [!] Must be 0 or greater. Try again.\n";
    }
}

float InventoryManager::readNonNegativeFloat(const std::string &prompt)
{
    float value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value && value >= 0.0f) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  [!] Must be 0.00 or greater. Try again.\n";
    }
}

std::string InventoryManager::readNonEmptyString(const std::string &prompt)
{
    std::string value;
    while (true) {
        std::cout << prompt;
        std::getline(std::cin, value);
        if (!value.empty()) return value;
        std::cout << "  [!] Name cannot be empty. Try again.\n";
    }
}

std::vector<Item> InventoryManager::fetchAll()
{
    std::vector<Item> buf(MAX_ITEMS);
    int n = list_items(buf.data(), MAX_ITEMS);
    buf.resize(static_cast<size_t>(n));
    return buf;
}

/* ============================================================ public CRUD */

bool InventoryManager::addItem(int id, const std::string &name, int quantity, float price)
{
    Item item{};
    item.id       = id;
    item.quantity = quantity;
    item.price    = price;
    item.is_deleted = 0;

    /* Safe copy – name is already validated non-empty by caller */
    strncpy(item.name, name.c_str(), MAX_NAME_LEN - 1);
    item.name[MAX_NAME_LEN - 1] = '\0';

    return add_item(item) == 1;
}

bool InventoryManager::viewItem(int id)
{
    Item item{};
    if (get_item(id, &item) != 1) return false;
    printHeader();
    printItem(item);
    std::cout << "\n";
    return true;
}

bool InventoryManager::updateItem(int id, const std::string &name, int quantity, float price)
{
    Item item{};
    item.id       = id;
    item.quantity = quantity;
    item.price    = price;
    item.is_deleted = 0;
    strncpy(item.name, name.c_str(), MAX_NAME_LEN - 1);
    item.name[MAX_NAME_LEN - 1] = '\0';

    return update_item(id, item) == 1;
}

bool InventoryManager::deleteItem(int id)
{
    return delete_item(id) == 1;
}

void InventoryManager::listAll(bool sortByName)
{
    std::vector<Item> items = fetchAll();

    if (items.empty()) {
        std::cout << "\n  (no active items in inventory)\n\n";
        return;
    }

    /* STL sort – two different comparators */
    if (sortByName) {
        std::sort(items.begin(), items.end(), [](const Item &a, const Item &b) {
            return std::string(a.name) < std::string(b.name);
        });
    } else {
        std::sort(items.begin(), items.end(), [](const Item &a, const Item &b) {
            return a.id < b.id;
        });
    }

    printHeader();
    for (const auto &item : items) {
        printItem(item);
    }
    std::cout << "\n  Total active items: " << items.size() << "\n\n";
}

/* ============================================================ interactive menu */

void InventoryManager::run()
{
    const std::string banner =
        "╔══════════════════════════════════╗\n"
        "║      INVENTORY MANAGER v1.0      ║\n"
        "╚══════════════════════════════════╝";

    const std::string menu =
        "\n"
        "  1) Add item\n"
        "  2) View item by ID\n"
        "  3) Update item\n"
        "  4) Delete item\n"
        "  5) List all items\n"
        "  6) Exit\n"
        "\n"
        "  Choice: ";

    std::cout << "\n" << banner << "\n";

    while (true) {
        std::cout << menu;

        int choice;
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "  [!] Invalid input.\n";
            continue;
        }
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        std::cout << "\n";

        switch (choice) {

        /* ---- Add ---- */
        case 1: {
            int         id  = readPositiveInt("  ID        : ");
            std::string nm  = readNonEmptyString("  Name      : ");
            int         qty = readNonNegativeInt("  Quantity  : ");
            float       pr  = readNonNegativeFloat("  Price     : ");

            if (addItem(id, nm, qty, pr))
                std::cout << "  [OK] Item " << id << " added.\n";
            else
                std::cout << "  [ERR] Could not add item (duplicate ID or bad data).\n";
            break;
        }

        /* ---- View ---- */
        case 2: {
            int id = readPositiveInt("  ID to view: ");
            if (!viewItem(id))
                std::cout << "  [ERR] Item " << id << " not found.\n";
            break;
        }

        /* ---- Update ---- */
        case 3: {
            int         id  = readPositiveInt("  ID to update : ");
            std::string nm  = readNonEmptyString("  New name     : ");
            int         qty = readNonNegativeInt("  New quantity : ");
            float       pr  = readNonNegativeFloat("  New price    : ");

            if (updateItem(id, nm, qty, pr))
                std::cout << "  [OK] Item " << id << " updated.\n";
            else
                std::cout << "  [ERR] Item " << id << " not found.\n";
            break;
        }

        /* ---- Delete ---- */
        case 4: {
            int id = readPositiveInt("  ID to delete: ");
            if (deleteItem(id))
                std::cout << "  [OK] Item " << id << " deleted.\n";
            else
                std::cout << "  [ERR] Item " << id << " not found.\n";
            break;
        }

        /* ---- List ---- */
        case 5: {
            std::cout << "  Sort by: (1) ID  (2) Name  [default=1]: ";
            std::string sortChoice;
            std::getline(std::cin, sortChoice);
            listAll(sortChoice == "2");
            break;
        }

        /* ---- Exit ---- */
        case 6:
            std::cout << "  Goodbye!\n\n";
            return;

        default:
            std::cout << "  [!] Unknown option. Choose 1-6.\n";
        }
    }
}
