# Inventory Manager

A console-based inventory management system demonstrating **mixed-language C/C++ programming**.  
The **data layer** is written in C (structs + binary file I/O), while the **UI/logic layer** is written in C++ (classes + STL).

---

## Project Structure

```
inventory_manager/
├── include/
│   ├── inventory.h          # C struct + function declarations (extern "C")
│   └── InventoryManager.h   # C++ class declaration
├── src/
│   ├── inventory.c          # C backend: fread/fwrite/fseek binary storage
│   ├── InventoryManager.cpp # C++ class: STL vector, sort, menu, input validation
│   └── main.cpp             # Entry point
├── Makefile                 # Primary build system
├── CMakeLists.txt           # Alternative CMake build
├── .gitignore
└── README.md
```

---

## How It Works

| Layer | Language | Responsibility |
|-------|----------|---------------|
| `inventory.c` | C (C11) | Binary file I/O with `fread`/`fwrite`/`fseek`. Soft delete via `is_deleted` flag. |
| `InventoryManager.cpp` | C++ (C++17) | `std::vector` for buffering, `std::sort` for ordering, input validation, interactive menu. |
| `main.cpp` | C++ | Creates `InventoryManager` and calls `run()`. |

Data is persisted in **`inventory.dat`** (binary, same directory as the executable).  
Records are never physically removed — deletions set `is_deleted = 1`.

---

## Build Instructions

### Option A — Make (recommended)

**Prerequisites:** `gcc`, `g++`, `make`

```bash
# Clone / enter the directory
cd inventory_manager

# Build
make

# Run
./inventory_manager

# Build + run in one step
make run

# Remove build artifacts and data file
make clean
```

### Option B — CMake

**Prerequisites:** `cmake >= 3.10`, `gcc`, `g++`

```bash
mkdir build_cmake && cd build_cmake
cmake ..
make
./inventory_manager
```

### Windows (MSYS2 / MinGW)

```bash
# Install gcc, g++, make via pacman, then:
make
inventory_manager.exe
```

---

## Features

| # | Feature | Detail |
|---|---------|--------|
| 1 | **Add item** | Stores a new record; rejects duplicate IDs |
| 2 | **View item** | Looks up a single active item by ID |
| 3 | **Update item** | Overwrites a record in-place with `fseek` |
| 4 | **Delete item** | Soft-delete (`is_deleted = 1`); never shown again |
| 5 | **List all** | Shows active items sorted by ID or Name via `std::sort` |
| 6 | **Exit** | Saves automatically (file is updated after every write) |

---

## Menu

```
╔══════════════════════════════════╗
║      INVENTORY MANAGER v1.0      ║
╚══════════════════════════════════╝

  1) Add item
  2) View item by ID
  3) Update item
  4) Delete item
  5) List all items
  6) Exit
```

---

## Input Validation Rules

| Field | Rule |
|-------|------|
| ID | Must be a **positive integer** (> 0) |
| Name | Must be **non-empty** (max 39 chars) |
| Quantity | Must be **≥ 0** |
| Price | Must be **≥ 0.00** |

Invalid input prompts the user to re-enter (no crash).

---

## Test Cases

The following scenarios were manually verified:

- **TC-1 — Add & Persist**  
  Added items with IDs 1, 2, 3. Exited. Re-launched. Chose *List all* → all 3 items appeared.

- **TC-2 — Duplicate ID rejection**  
  With item ID 1 already present, attempted to add another item with ID 1 → message `[ERR] Could not add item (duplicate ID or bad data)` shown; file unchanged.

- **TC-3 — Update persists across restarts**  
  Updated item 2's name to "Widget Pro" and price to 49.99. Exited. Re-launched. Chose *View item 2* → updated values displayed correctly.

- **TC-4 — Soft delete**  
  Deleted item 3. Chose *List all* → item 3 absent. Chose *View item 3* → `[ERR] Item 3 not found`. Re-launched → item 3 still absent.

- **TC-5 — Invalid input handling**  
  Entered `-5` as ID → re-prompted.  
  Entered empty string as name → re-prompted.  
  Entered `-1.50` as price → re-prompted.  
  All edge cases handled gracefully without crashing.

---

## C Backend API

```c
int add_item    (const Item item);                   // 1=success, 0=fail
int get_item    (int id, Item *out);                 // 1=found,   0=not found
int update_item (int id, const Item updated);        // 1=success, 0=not found
int delete_item (int id);                            // 1=success, 0=not found
int list_items  (Item *buffer, int max_items);       // returns count
```

---

## License

MIT — free to use, modify, and distribute.
