#ifndef INVENTORY_MANAGER_H
#define INVENTORY_MANAGER_H

#include "inventory.h"
#include <vector>
#include <string>

/* Maximum number of items we'll ever list in one call */
static const int MAX_ITEMS = 1024;

class InventoryManager {
public:
    /* CRUD wrappers */
    bool addItem(int id, const std::string &name, int quantity, float price);
    bool viewItem(int id);
    bool updateItem(int id, const std::string &name, int quantity, float price);
    bool deleteItem(int id);

    /* List all active items, sorted by id (pass sortByName=true for name sort) */
    void listAll(bool sortByName = false);

    /* Interactive menu loop – runs until user chooses Exit */
    void run();

private:
    /* Print a single item row */
    static void printItem(const Item &item);

    /* Print the table header */
    static void printHeader();

    /* Validated input helpers */
    static int  readPositiveInt(const std::string &prompt);
    static int  readNonNegativeInt(const std::string &prompt);
    static float readNonNegativeFloat(const std::string &prompt);
    static std::string readNonEmptyString(const std::string &prompt);

    /* Fetch all active items into a vector */
    std::vector<Item> fetchAll();
};

#endif /* INVENTORY_MANAGER_H */
