#ifndef INVENTORY_H
#define INVENTORY_H

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_NAME_LEN 40
#define INVENTORY_FILE "inventory.dat"

typedef struct {
    int   id;
    char  name[MAX_NAME_LEN];
    int   quantity;
    float price;
    int   is_deleted;
} Item;

/* Returns 1 on success, 0 on failure (e.g. duplicate ID) */
int add_item(const Item item);

/* Fills *out with the item matching id. Returns 1 on success, 0 if not found */
int get_item(int id, Item *out);

/* Overwrites the record for id with updated. Returns 1 on success, 0 if not found */
int update_item(int id, const Item updated);

/* Soft-deletes the record for id. Returns 1 on success, 0 if not found */
int delete_item(int id);

/* Copies up to max_items active items into buffer. Returns count copied. */
int list_items(Item *buffer, int max_items);

#ifdef __cplusplus
}
#endif

#endif /* INVENTORY_H */
